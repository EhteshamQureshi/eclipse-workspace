import java.util.ArrayList;

public class MyArray extends ArrayList<String>{
	
}
