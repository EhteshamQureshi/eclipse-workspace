package GUI;

import javafx.event.ActionEvent;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Label;

public class PlayerSelection implements EventHandler<MouseEvent>{

	Game game;
	
	public PlayerSelection(Game box) {
		game = box;
	}
	
	public void handle(MouseEvent event) {
	//test test test test	
	}
}
